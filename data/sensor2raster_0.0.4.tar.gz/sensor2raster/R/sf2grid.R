# BLANK GRID
# Creates an empty RasterLayer for a given geometry
# Lorenz Menendez
# 05/07/2020

#' Cover an sf object with a blank raster
#'
#' Takes an sf object and initializes a blank RasterLayer with the same extent and projection as the sf object, with a user-specified resolution.
#'
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @param sf.objj sf object over which to create a grid.
#' @param resolution value specifying the size of each grid cell. Units correspond to the units of the sf object's projection.
#' @return A RasterLayer with the same extent and projection of the inputted sf object, and a user-specified resolution.

#' @export
#' @import sf
#' @import sp
#' @import raster
sf2grid = function(sf.obj, resolution){

        # Initialize a Raster
        blank.raster = raster::raster()

        # Configure Blank Raster with correct CRS, bbox, resolution
        crs(blank.raster) = st_crs(sf.obj)$proj4string
        extent(blank.raster) = extent(sf.obj)
        res(blank.raster) = resolution

        return(blank.raster)
}
