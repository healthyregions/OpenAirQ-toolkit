# BOX HELPER FUNCTIONS
# Script defining various helpful functions related to importing or exporting to Box.com (Box_Helper_Functions.R)
# Lorenz Menendez
# 11/14/2019 (Updated: 05/25/2020)

#' Read Raster from URL
#'
#' Downloads and unzips .zip files from URL containing Raster files, then imports them into R.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @param URL Character vector containing a URL to download the .zip file from.
#' @param ... Any additional arguments passed to raster::brick()
#' @return A Raster object


#' @export
read_raster = function(URL, ...){

        # Fetch the temporary directory path
        temp.file = tempfile()

        # Download Zipped file to temp directory
        download.file(URL, destfile = temp.file)

        # Unzip the files in temp directory
        files = unzip(temp.file, exdir = dirname(temp.file))

        # Read the unzipped files into R as a RasterBrick
        raster = raster::brick(files[1], ...)

        # Delete Temporary Files and
        unlink(temp.file)

        # Return Raster
        return(raster)

}
