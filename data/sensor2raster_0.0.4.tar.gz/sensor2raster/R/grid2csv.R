# GRID 2 CSV
# Converts a List of RasterStacks to CSV Format with various specs.
# Lorenz Menendez
# 05/11/2020


#' Extract Rasters to data.frames
#'
#' Extract a list of Raster objects to data.frame in its entirety or by relevant layers and geometries. This data.frame can then be exported to a CSV.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @param rasters List object containing Raster objects with the same number of layers and layer names.
#' @param var.names Character vector containing a given name to be used in the outputted data frame. Must have the same length as the list of rasters.
#' @param sf.obj (Optional) sf object containing geometries over which to extract data.
#' @param layers (Optional) Character vector used to subset for a particular layer in each Raster object by name. Defaults to the names of layers in the first raster object.
#' @param fun (Optional) R function to handle aggregation by sf object. Defaults to taking the mean of raster cells the overlap with sf geometries.
#' @return A data.frame in layer-wide format. Each column represent a common layer across each raster object. Rows are grouped by variable name. For extracts using sf geometries, a unique Raster_Cell number is given that represents the location of the point geometry on the raster or the location of the centroid of line or polygon features on the raster.


#' @export
#' @import velox
grid2csv = function(rasters, var.names, sf.obj = NULL, layers = names(rasters[[1]]), fun = mean){


        # OPTION 1: Direct Conversion from Raster to CSV
        if(missing(sf.obj) == TRUE){

                # Converting list of Rasters to data.frame
                message('Converting Rasters to Data Frames...')

                data.list = lapply(rasters, function(r){

                        # STEP 1: Subset Rasters based on Given Layer Names
                        r = raster::subset(r, layers)

                        x = as.data.frame(r) %>%
                                tibble::rowid_to_column() %>%
                                dplyr::rename(Raster.Cell = rowid) %>%
                                dplyr::filter_all(any_vars(!is.na(.)))
                        return(x)
                })
        }

        if(missing(sf.obj) == FALSE){

                # OPTION 2: Extraction to CSV by Point Layer
                if(sf::st_geometry_type(sf.obj, by_geometry = FALSE) == 'POINT'){

                        data.list = lapply(rasters, function(r){

                                # STEP 1: Subset Rasters based on Given Layer Names
                                r = raster::subset(r, layers)

                                # STEP 2: Copy the Raster and Create a Raster with values 1:ncells(raster) --> Creates a Raster of Unique Cell IDs
                                message("Generating ID Raster...")
                                r.idx = r[[1]] %>% raster::setValues(1:ncell(r[[1]])) %>% setNames('Raster_Cell')

                                r = raster::addLayer(r.idx, r)

                                # STEP 3: Use Velox to extract only from cells within the point layer
                                message('Extracting Values at Points...')
                                # Extract Points with Velox
                                r.vx = velox(r)
                                data = r.vx$extract_points(points)

                                # Convert to data.frame, remove duplicates, add appropriate names
                                data.df = data %>% data.frame() %>% arrange(.[,1])

                                names(data.df) = names(r)

                                # STEP 4: Subset based on function inputs
                                data.df = data.df %>% dplyr::select(Raster_Cell, layers)

                                return(data.df)
                        })
                }

                # OPTION 3: Extraction to CSV by Line or Polygon with an aggregation function
                if(sf::st_geometry_type(sf.obj, by_geometry = FALSE) %in% c('POLYGON', 'MULTIPOLYGON', 'LINESTRING', 'MULTILINESTRING')){

                        data.list = lapply(rasters, function(r){

                                # STEP 1: Subset Rasters based on Given Names
                                r = raster::subset(r, layers)

                                # STEP 2: Copy the Raster and Create a Raster with values 1:ncells(raster) --> Creates a Raster of Unique Cell IDs
                                message("Generating ID Raster...")
                                r.idx = r[[1]] %>% setValues(1:ncell(r[[1]])) %>% setNames('Raster_Cell')

                                # STEP 3: Use Velox to extract average value of cells within the feature
                                message('Extracting Values at features...')

                                # Extract Points with Velox
                                r.vx = velox(r)
                                data = r.vx$extract(sp = sf.obj, fun = fun , df = TRUE)

                                # Extract proper cell.ID
                                r.idx.vx = velox(r.idx)
                                ID = r.idx.vx$extract_points(sp = sf.obj %>% st_centroid())
                                #data[,1] = ID[,1]
                                data = cbind(ID[,1], data)

                                # Convert to data.frame, remove duplicates, add appropriate names
                                data.df = data %>% data.frame() %>% arrange(.[,1])

                                names(data.df) =  c('Raster_Cell', 'sf_join', names(r))

                                return(data.df)

                        })
                }
        }


        # Adding the Desired Variable Names to the List
        names(data.list) = var.names

        # Converting list of data.frames to a single df
        message('Binding Data Frames...')
        rasters.df = bind_rows(data.list, .id = "Var_Name")


        message('DONE!')
        return(rasters.df)

}

