# DATA ANALYSIS
# Create Optimized IDW Raster Surface from a standardized 'data.frame' (IDW_Surface_Creator.R)
# Lorenz Menendez
# 04/06/2020

#' Create Optimized IDW Surface
#'
#' Runs multiple IDW interpolations with different parameters and selects the IDW interpolation with the lowest RMSE from five-fold cross-validation.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param wrangled.data A SpatialPointsDataFrame of wrangled and aggregated sensor data.
#' @param reference.grid A RasterLayer on which to project the interpolation.
#' @return A RasterStack containing Optimized IDW interpolations for each time period specified.
#'

#' @export
IDW_creator = function(wrangled.data, reference.grid){

        # STEP 1: Setting up IDW Interpolation

                # Create empty list to store interpolations
                idw.list <- list()

                unique.times <- unique(wrangled.data$moyr)

        # STEP 2: Define functions to find optimal parameters

        RMSE <- function(observed, predicted) {
                sqrt(mean((predicted - observed)^2, na.rm=TRUE))
        }

        f1 <- function(x, test, train) {
                nmx <- x[1]
                idp <- x[2]
                if (nmx < 1) return(Inf)
                if (idp < .001) return(Inf)
                m <- gstat(formula=Mean~1, locations=train, nmax=nmx, set=list(idp=idp))
                p <- predict(m, newdata=test, debug.level=0)$var1.pred
                RMSE(test$Mean, p)
        }

        # STEP 3: Run the Optimized IDW Workflow for each month
        for(i in 1:length(unique.times)) {
                this.temp <- wrangled.data[wrangled.data$moyr == unique.times[i],] #temp from this mo/yr
                idw.list[[i]] <- gstat::gstat(formula = this.temp$Mean ~ 1, locations = this.temp, nmax = 5, set=list(idp=0)) %>%
                        interpolate(reference.grid, .)



                i <- sample(nrow(this.temp), 0.2 * nrow(this.temp))
                tst <- this.temp[i,]
                trn <- this.temp[-i,]
                opt <- optim(c(8, .5), f1, test=tst, train=trn)

                m <- gstat(formula=this.temp$Mean~1, locations=this.temp, nmax=opt$par[1], set=list(idp=opt$par[2])) %>%
                        interpolate(reference.grid, .)

                }

        temp.raster.stack <- stack(idw.list)

        return(temp.raster.stack)
}
