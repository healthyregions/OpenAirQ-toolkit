# DATA WORKFLOW
# Converting data from a sensor point location to an IDW raster surface (SensorPointData_to_RasterSurface.R)
# Lorenz Menendez
# 01/23/2019

#' Interpolate Raw Sensor Data Directly
#'
#' Interpolates Raw Sensor Data (in EPA or ASOS format) from a CSV or API Query directly onto a RasterLayer
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param EPA.formatted.data SpatialPointsDataFrame of sensor locations and attribute table in EPA format.
#' @param data.EPSG Numeric EPSG code for outputted sensor locations.
#' @return A SpatialPointsDataFrame with sensor locations and summarized sensor data.
#'

sensor2raster = function(Sensor.data, data.type, reference.grid, subvariable, data.EPSG = 4326){

        # STEP 2: Wrangle Data Based on Source ("ASOS" or "EPA")
        paste("Wrangling", data.type, 'Data...') %>% message

        if(data.type == "ASOS"){
                data = asos2epa(Sensor.data, data.EPSG = data.EPSG, reference.grid = reference.grid, variable.of.interest = subvariable)
        }

        if(data.type == "EPA") {
                data = EPA_wrangler(Sensor.data, data.EPSG = data.EPSG, reference.grid = reference.grid)
        }

        # STEP 4: Aggregate Data to Monthly and Quarterly Scales
        message("Aggregating Data to Monthly and Quarterly Scales...")

        data.agg = EPA_aggregator(data, data.EPSG = data.EPSG)

        # Extract year range from previous function output
        year.range = data.agg[[3]]

        # Delete from output
        data.agg = data.agg[- 3]

        # STEP 5: Create IDW Surface for each time scale
        paste("Creating IDW Surface for each Month and Quarter between", year.range[1], "and", tail(year.range, 1), "...") %>% message()

        raster = lapply(data.agg, IDW_creator, reference.grid = reference.grid)

        # STEP 6: Convert Raster to Vector Grid and Title Columns Appropriately.
        message("Cleaning up Raster Grids...")

        final.raster = tidy_raster(raster, year.range = year.range)

        # STEP 7: Return the Final Output
        message("Finished! Monthly Data is the first element in outputted list, Quarterly is the 2nd element")
        return(final.raster)

}
