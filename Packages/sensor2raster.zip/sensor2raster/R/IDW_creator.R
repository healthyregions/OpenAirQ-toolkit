#' Create IDW Raster Based on Sensor Locations and Data
#'
#'This is the third function in the workflow that converts raw sensor data (as given by an API or downloaded from website) into an IDW interpolated surface.
#'This function takes attribute data in a SpatialPointsDataFrame, summarized by monthy and year, and interpolates the value of the sensor variable across a given RasterLayer for each given Month and Quarter in the summarized data.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param wrangled.data SpatialPointsDataFrame of sensor locations and summarized attribute table in EPA format.
#' @param refrence.grid RasterLayer over which values will be interpolated. Sensors need not necessarily within the RasterLayer.
#' @return A RasterStack containing an IDW RasterLayer for each month or quarter.
#'

IDW_creator = function(wrangled.data, reference.grid){

        # STEP 1: Setting up IDW Interpolation

        # Create empty list to store interpolations
        idw.list <- list()

        unique.times <- unique(wrangled.data$moyr)

        # STEP 2: Run the IDW
        # for(i in 1:length(unique.times)) {
        #         this.temp <- wrangled.data[wrangled.data$moyr == unique.times[i],] #temp from this mo/yr
        #         idw.list[[i]] <- idw(this.temp$Mean ~ 1, this.temp, area.grid)
        # }

        for(i in 1:length(unique.times)) {
                this.temp <- wrangled.data[wrangled.data$moyr == unique.times[i],] #temp from this mo/yr
                idw.list[[i]] <- gstat::gstat(formula = this.temp$Mean ~ 1, locations = this.temp, nmax = 5, set=list(idp=0)) %>%
                        raster::interpolate(reference.grid, .)
        }

        temp.raster.stack <- raster::stack(idw.list)

        return(temp.raster.stack)
}
