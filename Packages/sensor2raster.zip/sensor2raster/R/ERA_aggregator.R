# DATA WRANGLING
# Take data in EPA format and Aggreate to Monthly and Quarterly timescales (EPA_Data_Aggregator.R)
# Lorenz Menendez
# 01/23/2020

#' Aggregate Attribute Table Data to Monthly and Quarterly Timescales
#'
#'This is the second function in the workflow that converts raw sensor data (as given by an API or downloaded from website) into an IDW interpolated surface.
#'This function takes attribute data in a SpatialPointsDataFrame and summarises the data by month and quarter. The outputted attribute table will have a new variable 'moyr' that tags unique quarters and months for later processing.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param EPA.formatted.data SpatialPointsDataFrame of sensor locations and attribute table in EPA format.
#' @param data.EPSG Numeric EPSG code for outputted sensor locations.
#' @return A SpatialPointsDataFrame with sensor locations and summarized sensor data.
#'

EPA_aggregator = function(EPA.formatted.data, data.EPSG){

        # STEP 1: Monthly Aggregations (Adapted from LargeAreaTemperatureMonthly.R)
        data.monthly <- EPA.formatted.data@data %>%
                dplyr::group_by(moyr, `site_num`, latitude, longitude) %>%
                dplyr::summarise(Mean = base::mean(`arithmetic_mean`, na.rm = TRUE))

        sp::coordinates(data.monthly) <- data.monthly[,c("longitude", "latitude")]
        sp::proj4string(data.monthly) <- paste0("+init=epsg:", data.EPSG) %>% sp::CRS()
        data.monthly = sp::spTransform(data.monthly, sp::proj4string(EPA.formatted.data))


        # STEP 2: Quarterly Aggregation (Adpated from LargeAreaTemperature.R)

        unique.moyr <- unique(EPA.formatted.data$moyr)

        c = 1
        d = 1

        unique.moyr <- sort(unique.moyr)

        data.quarterly <- data.frame()

        qtrs = c()

        while(c <= length(unique.moyr)) {

                this.qtr <- unique.moyr[c:(c+2)]
                this.data <- data.monthly[(data.monthly$moyr %in% this.qtr),]

                this.data <- this.data@data %>%
                        dplyr::group_by(`site_num`, longitude, latitude) %>%
                        dplyr::summarise(Mean = base::mean(Mean, na.rm = TRUE))

                this.data$moyr <- d

                if(c != 1) {
                        data.quarterly <- rbind(data.quarterly, this.data)
                } else {
                        data.quarterly <- this.data
                }

                qtrs = c(qtrs, this.qtr)

                c = c + 3
                d = d+1
        }


        sp::coordinates(data.quarterly) <- data.quarterly[,c("longitude", "latitude")]
        sp::proj4string(data.quarterly) <- paste0("+init=epsg:", data.EPSG) %>% sp::CRS()
        data.quarterly = sp::spTransform(data.quarterly, sp::proj4string(EPA.formatted.data))

        # STEP 3: Extract Start / End Year Range for future functions
        range = qtrs %>% as.Date(origin = "1970-01-01")
        year.range = list()
        year.range[[1]] = min(range) %>% lubridate::year()
        year.range[[2]] = max(range) %>% lubridate::year()

        year.range = year.range[[1]]:year.range[[2]]


        list(data.monthly, data.quarterly, year.range) %>% return()

}
