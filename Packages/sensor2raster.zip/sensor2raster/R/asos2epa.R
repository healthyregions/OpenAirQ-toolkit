# DATA WRANGLING
# Take CSVs of ASOS data and convert to EPA format (ASOS_to_EPA_Wrangler.R)
# Lorenz Menendez
# V1: 10/18/2019
# V2: 01/23/2020

#' Wrangle ASOS Data Frame to EPA Data Frame.
#'
#'This is the first function in the workflow that converts raw sensor data (as given by an API or downloaded from website) into an IDW interpolated surface.
#'This function converts an FAA Automated Surface Observation System (ASOS) data frame into a SpatialPointsDataFrame for later processing in the workflow.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @param ASOS.data data.frame of ASOS output read directly into R.
#' @param data.EPSG Numeric EPSG code of the ASOS data, defaults to 4326.
#' @param reference.grid RasterLayer on which to extract the CRS
#' @param variable.of.interest String of the column header of the variable to interpolate
#' @return A SpatialPointsDataFrame that matches the attribute table structure of EPA weather data.


asos2epa = function(ASOS.data, data.EPSG = 4326, reference.grid, variable.of.interest){

        # STEP 1: Rename Headers, Add required calculated columns, get rid of NA values
        ASOS.data.EPA = ASOS.data  %>%
                dplyr::rename(site_num = station,
                       date_local = valid,
                       longitude = lon,
                       latitude = lat,
                       arithmetic_mean = !!as.symbol(variable.of.interest)) %>%
                dplyr::mutate(moyr = lubridate::dmy(paste(01, lubridate::month(.$date_local), lubridate::year(.$date_local), sep = "-"))) %>%
                tidyr::drop_na(arithmetic_mean)

        # STEP 2: Make the Data Spatial

        # Make Spatial
        sp::coordinates(ASOS.data.EPA) = ASOS.data.EPA[,c("longitude", "latitude")]
        sp::proj4string(ASOS.data.EPA) = paste0("+init=epsg:", data.EPSG) %>% sp::CRS()
        ASOS.data.EPA = sp::spTransform(ASOS.data.EPA, sp::proj4string(reference.grid))


        ASOS.data.EPA %>%  return()

}
