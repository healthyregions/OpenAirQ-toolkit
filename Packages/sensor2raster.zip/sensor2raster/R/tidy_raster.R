# DATA CLEANING
# Creating the Final Vector Data Product (IDW_Raster_Tidying.R)
# Lorenz Menendez
# 10/20/2019

#' Groups Outputted IDW Rasters by Month/Quarter and Improves Naming Conventions
#'
#'This is the fourth and final function in the workflow that converts raw sensor data (as given by an API or downloaded from website) into an IDW interpolated surface.
#'This function takes a list of raw IDW raster output and improves the naming and data structure.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param raw.raster List object of Monthly and Quarterly IDW RasterStacks without proper names
#' @param year.range Range representing the temporal coverage of the IDW RasterStack
#' @return A List object with two elements: First, RasterStack of Monthly IDW rasters with 'Mx.20xx' naming convention. Second, a RasterStack of Quarterly IDW rasters with 'Qx.20xx' naming convention.
#'

tidy_raster = function(raw.raster, year.range) {

        # STEP 1: Rename Column Headers using a custom-defined function
        names.generator = function(prefix, subunit.range, year.range){
                names = c()

                for(i in 1:length(year.range)){
                        titles = paste(paste0(prefix, subunit.range), year.range[i], sep = ".")
                        names = c(names, titles)
                }

                return(names)
        }

        # CASE 1: When each layer represents a month

        names = names.generator("M", 1:12, year.range)

        names(raw.raster[[1]]) = names

        # CASE 2: When each layer presents a month

        names = names.generator("Q", 1:4, year.range)

        names(raw.raster[[2]]) = names

        # STEP 4: Create List of outputs with corresponding names
        names(raw.raster) = c("Monthly_Raster_Data", "Quarterly_Raster_Data")

        raw.raster %>% return()

}


