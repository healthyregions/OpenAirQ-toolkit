# DATA WRANGLING
# Take raw EPA Data and Wrangle it for processing (EPA_Data_Wrangler.R)
# Lorenz Menendez
# 10/18/2019

#' Convert EPA Data Table to Spatial Data
#'
#' This function is the second Wrangles sensor data in an EPA-formatted table into a Spatial object with appropriate CRS for later processing.
#'
#' @author Lorenz Menendez, \email{lmenendez@@uchicago.edu}
#' @author Isaac Kamber, \email{ikamber@@uchicago.edu}
#' @param data data.frame of sensor data in the EPA data table format.
#' @param data.EPSG Numeric EPSG code of the data in data table, defaults to 4326.
#' @param reference.grid RasterLayer from which output CRS will be determined
#' @return A SpatialPointsDataFrame object of sensor locations with attribute table of sensor data.

EPA_wrangler = function(data, data.EPSG, reference.grid){

        # STEP 1: Standardize Columns & Names
        names(data) = names(data) %>% tolower() %>% gsub(" ", "_", .)
        data = data %>% dplyr::select(3, 6, 7, 12, "arithmetic_mean")

        names(data) = c('site_num', 'latitude', 'longitude', 'date_local', 'arithmetic_mean')

        # STEP 2: Convert to Spatial Data & Format Dates
        sp::coordinates(data) = data[,c("longitude", "latitude")]
        sp::proj4string(data) = paste0("+init=epsg:", data.EPSG) %>% sp::CRS()
        data = sp::spTransform(data, sp::proj4string(reference.grid))

        data$moyr = lubridate::dmy(paste(01, lubridate::month(data$ `date_local`), lubridate::year(data$`date_local`), sep = "-"))

        data %>% return()
}
